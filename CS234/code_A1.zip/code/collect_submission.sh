rm -f assignment1.zip
zip -r assignment1.zip vi_and_pi.py
